"""Sample tests for PyACL. Run with:  python -m pytest tests
Passing them does NOT mean you will pass all the tests; write your own too.
"""
import os

import pytest

from pyacl import ACE, Effect, GroupCycleError, Policy, analyze

EXAMPLE = os.path.join(os.path.dirname(__file__), "..", "policies", "example.json")


@pytest.fixture
def policy():
    return Policy.load(EXAMPLE)


def make():
    p = Policy()
    for u in ["alice", "bob", "carol"]:
        p.add_user(u)
    p.add_resource("/doc", "carol")
    return p


def test_owner_is_allowed():
    assert make().check("carol", "write", "/doc")


def test_default_is_deny():
    assert not make().check("alice", "read", "/doc")


def test_owner_can_grant_read():
    p = make()
    p.add_ace("carol", "/doc", ACE("alice", frozenset({"read"}), Effect.ALLOW))
    assert p.check("alice", "read", "/doc")
    assert not p.check("alice", "write", "/doc")


def test_deny_beats_allow():
    p = make()
    p.add_ace("carol", "/doc", ACE("alice", frozenset({"read"}), Effect.ALLOW))
    p.add_ace("carol", "/doc", ACE("alice", frozenset({"read"}), Effect.DENY))
    assert not p.check("alice", "read", "/doc")


def test_non_admin_cannot_change_acl():
    p = make()
    with pytest.raises(PermissionError):
        p.add_ace("bob", "/doc", ACE("bob", frozenset({"read"}), Effect.ALLOW))


def test_group_cycle_rejected():
    p = Policy()
    p.add_group("a", ["group:b"])
    with pytest.raises(GroupCycleError):
        p.add_group("b", ["group:a"])


def test_nested_group_member_inherits_grant(policy):
    # dave is in interns, which is inside eng; /projects grants eng read.
    assert policy.check("dave", "read", "/projects/apollo/specs.pdf")


def test_nearer_deny_wins(policy):
    assert not policy.check("dave", "read", "/projects/apollo/secret/plan.txt")
    assert policy.check("bob", "read", "/projects/apollo/secret/plan.txt")


def test_who_can(policy):
    # alice owns the secret folder; bob is in eng; dave is denied; carol has no grant.
    assert policy.who_can("read", "/projects/apollo/secret/plan.txt") == {"alice", "bob"}


def test_analyze_finds_star_write():
    p = make()
    p.add_ace("carol", "/doc", ACE("*", frozenset({"write"}), Effect.ALLOW))
    kinds = {(f["type"], f["principal"]) for f in analyze(p)}
    assert ("over_privileged", "*") in kinds
