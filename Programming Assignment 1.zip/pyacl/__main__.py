"""Command line: python -m pyacl check|explain|who-can|analyze <policy.json> ..."""


import argparse
import sys

from . import Policy, analyze


def main(argv=None):
    # To DO 
    return 0


if __name__ == "__main__":
    sys.exit(main())
