"""PyACL starter code.

Provided for you: the data classes, GroupCycleError, Policy.load and
Policy.save. Everything marked TODO is yours to implement. Do not rename
anything below; the autograder imports these names.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from enum import Enum

PERMISSIONS = frozenset({"read", "write", "execute", "delete", "share", "admin"})


class Effect(Enum):
    ALLOW = "allow"
    DENY = "deny"


class GroupCycleError(Exception):
    """Raise this when add_group would create a membership cycle."""


@dataclass(frozen=True)
class ACE:
    principal: str  # "alice", "group:eng", "*", or "@owner"
    permissions: frozenset
    effect: Effect
    inherit: bool = False

    def __post_init__(self):
        object.__setattr__(self, "permissions", frozenset(self.permissions))


@dataclass
class Decision:
    allowed: bool
    reasons: list  # human-readable, one per deciding ACE
    deciding_path: str | None  # resource whose ACL decided, None if default deny


class Policy:
    def __init__(self):
        self.users: set[str] = set()
        self.groups: dict[str, list[str]] = {}      # name -> members ("bob", "group:x")
        self.resources: dict[str, dict] = {}        # path -> {"owner": str, "acl": [ACE]}

    # ---------------- provided ----------------
    @classmethod
    def load(cls, path: str) -> "Policy":
        with open(path) as f:
            data = json.load(f)
        p = cls()
        for u in data.get("users", []):
            p.add_user(u)
        for name, members in data.get("groups", {}).items():
            p.add_group(name, members)
        for rpath, spec in data.get("resources", {}).items():
            p.add_resource(rpath, spec["owner"])
            for a in spec.get("acl", []):
                ace = ACE(a["principal"], frozenset(a["permissions"]),
                          Effect(a["effect"]), a.get("inherit", False))
                # Loading bypasses the admin check on purpose.
                p.resources[rpath]["acl"].append(ace)
        return p

    def save(self, path: str) -> None:
        data = {
            "users": sorted(self.users),
            "groups": {g: list(m) for g, m in self.groups.items()},
            "resources": {
                r: {"owner": s["owner"], "acl": [
                    {"principal": a.principal, "permissions": sorted(a.permissions),
                     "effect": a.effect.value, "inherit": a.inherit} for a in s["acl"]]}
                for r, s in self.resources.items()},
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    # ---------------- TODO: Part 1 ----------------
    def add_user(self, name: str) -> None:
        raise NotImplementedError

    def add_group(self, name: str, members: list[str]) -> None:
        """Create or replace a group. Members may name groups not created yet.
        Raise GroupCycleError (and change nothing) if this creates a cycle."""
        raise NotImplementedError

    def add_resource(self, path: str, owner: str) -> None:
        raise NotImplementedError

    def add_ace(self, actor: str, path: str, ace: ACE) -> None:
        """Raise PermissionError unless actor holds admin on path."""
        raise NotImplementedError

    def remove_ace(self, actor: str, path: str, ace: ACE) -> None:
        """Raise PermissionError unless actor holds admin on path."""
        raise NotImplementedError

    def check(self, user: str, permission: str, path: str) -> bool:
        raise NotImplementedError

    def explain(self, user: str, permission: str, path: str) -> Decision:
        raise NotImplementedError

    # ---------------- TODO: Part 3 ----------------
    def who_can(self, permission: str, path: str) -> set[str]:
        raise NotImplementedError


def analyze(policy: Policy) -> list[dict]:
    """TODO Part 3. Return [{"type": "shadowed"|"over_privileged"|"orphan",
    "path": str, "principal": str}, ...]."""
    raise NotImplementedError
